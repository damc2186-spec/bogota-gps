# Bogotá GPS — versión 0.1

Prototipo web instalable (PWA) para Android.

Incluye:
- Ubicación GPS del dispositivo.
- Mapa centrado en Bogotá.
- Seguimiento de posición.
- Búsqueda de destino con Nominatim/OpenStreetMap.
- Cálculo básico de ruta con OSRM.
- Panel de alertas preparado para integrar fuentes oficiales y reportes comunitarios.
- Instalación como aplicación desde Chrome cuando se publique bajo HTTPS.

## Cómo probarlo
1. Sirve esta carpeta desde un servidor HTTPS o usa un hosting estático como GitHub Pages.
2. Abre `index.html` desde la URL HTTPS en Chrome Android.
3. Concede permiso de ubicación.
4. Busca un destino y pulsa "Trazar ruta".
5. Para instalarla: menú de Chrome > "Instalar aplicación" / "Añadir a pantalla de inicio".

## Próxima etapa
- Navegación giro a giro.
- Voz.
- Base de datos de alertas.
- Reportes de usuarios.
- Cámaras y cierres usando fuentes verificadas.
- Backend y cuentas de usuario.
