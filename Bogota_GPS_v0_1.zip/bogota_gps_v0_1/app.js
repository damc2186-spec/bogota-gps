const BOGOTA = [4.7110, -74.0721];
let map, userMarker, destinationMarker, routeLine, watchId, currentPosition;
const alerts = [];

function initMap(){
  map = L.map('map', {zoomControl:false}).setView(BOGOTA, 12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
    maxZoom:19,
    attribution:'© OpenStreetMap contributors'
  }).addTo(map);
  L.control.zoom({position:'bottomright'}).addTo(map);
}

function setUserPosition(lat, lon, accuracy){
  currentPosition = [lat, lon];
  const icon = L.divIcon({className:'user-dot',html:'<div style="width:22px;height:22px;background:#087ff5;border:4px solid white;border-radius:50%;box-shadow:0 0 0 7px #087ff544"></div>',iconSize:[22,22],iconAnchor:[11,11]});
  if(!userMarker) userMarker=L.marker(currentPosition,{icon}).addTo(map);
  else userMarker.setLatLng(currentPosition);
  document.getElementById('routeInfo').textContent = `GPS activo • precisión aprox. ${Math.round(accuracy||0)} m`;
}

function locate(){
  if(!navigator.geolocation){
    alert('Este dispositivo no permite GPS desde el navegador.');
    return;
  }
  navigator.geolocation.getCurrentPosition(p=>{
    setUserPosition(p.coords.latitude,p.coords.longitude,p.coords.accuracy);
    map.setView([p.coords.latitude,p.coords.longitude],15);
  }, e=>alert('No fue posible obtener la ubicación: '+e.message),{enableHighAccuracy:true,timeout:15000});
  if(watchId===undefined){
    watchId=navigator.geolocation.watchPosition(p=>setUserPosition(p.coords.latitude,p.coords.longitude,p.coords.accuracy),
      e=>console.warn(e),{enableHighAccuracy:true,maximumAge:3000,timeout:15000});
  }
}

async function searchDestination(){
  const q=document.getElementById('destination').value.trim();
  if(!q) return;
  const url=`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=co&q=${encodeURIComponent(q+', Bogotá, Colombia')}`;
  try{
    const res=await fetch(url,{headers:{'Accept-Language':'es'}});
    const data=await res.json();
    if(!data.length){alert('No encontramos ese destino.');return;}
    const lat=+data[0].lat, lon=+data[0].lon;
    if(destinationMarker) map.removeLayer(destinationMarker);
    destinationMarker=L.marker([lat,lon]).addTo(map).bindPopup(data[0].display_name).openPopup();
    map.setView([lat,lon],15);
    if(currentPosition) await drawRoute(currentPosition,[lat,lon]);
    else document.getElementById('routeInfo').textContent='Activa tu ubicación para calcular la ruta.';
  }catch(err){alert('Error buscando el destino. Revisa tu conexión.');}
}

async function drawRoute(from,to){
  const url=`https://router.project-osrm.org/route/v1/driving/${from[1]},${from[0]};${to[1]},${to[0]}?overview=full&geometries=geojson`;
  try{
    const res=await fetch(url); const data=await res.json();
    if(data.code!=='Ok') throw new Error('Ruta no disponible');
    if(routeLine) map.removeLayer(routeLine);
    routeLine=L.geoJSON(data.routes[0].geometry,{style:{weight:6}}).addTo(map);
    const r=data.routes[0];
    document.getElementById('routeTitle').textContent='Ruta encontrada';
    document.getElementById('routeInfo').textContent=`${(r.distance/1000).toFixed(1)} km • aprox. ${Math.round(r.duration/60)} min`;
    map.fitBounds(routeLine.getBounds(),{padding:[40,140]});
  }catch(e){document.getElementById('routeInfo').textContent='No fue posible calcular la ruta.';}
}

function addAlert(type){
  const item={type,time:new Date().toLocaleTimeString('es-CO',{hour:'2-digit',minute:'2-digit'}),position:currentPosition};
  alerts.unshift(item);
  renderAlerts();
  document.getElementById('reportDialog').close();
}

function renderAlerts(){
  const list=document.getElementById('alertsList');
  list.innerHTML=alerts.length?alerts.slice(0,6).map(a=>`<div class="alertItem"><strong>${a.type}</strong><div style="font-size:12px;color:#9db0c1">${a.time} • reporte comunitario</div></div>`).join(''):'<div class="empty">Todavía no hay alertas comunitarias.</div>';
}

document.getElementById('locateBtn').onclick=locate;
document.getElementById('searchBtn').onclick=searchDestination;
document.getElementById('destination').addEventListener('keydown',e=>{if(e.key==='Enter')searchDestination()});
document.getElementById('routeBtn').onclick=locate;
document.getElementById('reportBtn').onclick=()=>document.getElementById('reportDialog').showModal();
document.getElementById('closeDialog').onclick=()=>document.getElementById('reportDialog').close();
document.querySelectorAll('.reportGrid button').forEach(b=>b.onclick=()=>addAlert(b.dataset.type));

initMap();

if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.warn));
